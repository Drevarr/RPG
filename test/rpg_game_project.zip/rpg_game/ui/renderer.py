class ConsoleUIRenderer:
    def display(self, message):
        print("[UI] " + message)
